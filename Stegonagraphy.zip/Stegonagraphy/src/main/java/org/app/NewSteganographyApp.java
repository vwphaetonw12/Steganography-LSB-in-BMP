package org.app;

import javafx.application.Application;

public class NewSteganographyApp {
    public static void main(String[] args) {
        Application.launch(SteganographyApp.class, args);
    }
}
